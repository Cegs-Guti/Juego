﻿using System;

namespace JuegoNamespace
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Bienvenido al juego!");

            // Ejemplo de inicialización y prueba de las clases.
            Sacerdote sacerdote = new Sacerdote("Samson", 100, 15);
            Barbaro barbaro = new Barbaro("Conan", 120, 20, 10);

            // Equipar a los personajes con equipo básico.
            Equipo equipoBasico = new Equipo(5, 3);
            sacerdote.Equipar(equipoBasico);
            barbaro.Equipar(equipoBasico);

            Console.WriteLine($"Vida inicial de {sacerdote.GetNombre()}: {sacerdote.GetVida()}");
            barbaro.Atacar(sacerdote);
            Console.WriteLine($"Vida restante de {sacerdote.GetNombre()}: {sacerdote.GetVida()}");
        }
    }

    class Personaje
    {
        private string nombre;
        private int vida;
        private int ataque;
        protected Equipo equipo; // Cambiado a protected para acceso en subclases.

        public Personaje(string nombre, int vida, int ataque)
        {
            this.nombre = nombre;
            this.vida = vida;
            this.ataque = ataque;
            this.equipo = null; // Inicializado como null.
        }

        public string GetNombre() => nombre;
        public int GetVida() => vida;
        public int GetAtaque() => ataque;

        public virtual void Atacar(Personaje objetivo) // Declarado como virtual.
        {
            int danio = ataque + (equipo?.GetModificadorAtaque() ?? 0);
            objetivo.RecibirDanio(danio);
        }

        public virtual void RecibirDanio(int danio) // Declarado como virtual.
        {
            vida -= danio;
            if (vida < 0) vida = 0;
        }

        public void Equipar(Equipo equipo)
        {
            this.equipo = equipo;
        }
    }

    class Barbaro : Personaje
    {
        private int furia;

        public Barbaro(string nombre, int vida, int ataque, int furia)
            : base(nombre, vida, ataque)
        {
            this.furia = furia;
        }

        public int GetFuria() => furia;

        public void IncrementarFuria()
        {
            furia += 10;
        }

        public override void Atacar(Personaje objetivo)
        {
            int danio = GetAtaque() + furia + (equipo?.GetModificadorAtaque() ?? 0);
            objetivo.RecibirDanio(danio);
            IncrementarFuria();
        }
    }

    class Sacerdote : Personaje
    {
        private static Random random = new Random();

        public Sacerdote(string nombre, int vida, int ataque)
            : base(nombre, vida, ataque)
        {
        }

        public override void RecibirDanio(int danio)
        {
            if (random.Next(4) == 0) // 1 de cada 4 ataques.
            {
                danio = (int)Math.Round(danio / 2.0); // Reducir el daño a la mitad.
                Console.WriteLine($"Las plegarias de {GetNombre()} han sido escuchadas. El daño se reduce a {danio}.");
            }

            base.RecibirDanio(danio);
        }
    }

    class Equipo
    {
        private int modificadorAtaque;
        private int modificadorArmadura;

        public Equipo(int modificadorAtaque, int modificadorArmadura)
        {
            this.modificadorAtaque = modificadorAtaque;
            this.modificadorArmadura = modificadorArmadura;
        }

        public int GetModificadorAtaque() => modificadorAtaque;
        public int GetModificadorArmadura() => modificadorArmadura;
    }
}