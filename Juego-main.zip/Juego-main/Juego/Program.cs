﻿using System;

namespace JuegoNamespace
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Bienvenido al juego!");
            // Aquí puedes inicializar el juego y probar las clases.
        }
    }

    class Personaje
    {
        private string nombre;
        private int vida;
        private int ataque;
        private Equipo equipo;

        public Personaje(string nombre, int vida, int ataque)
        {
            this.nombre = nombre;
            this.vida = vida;
            this.ataque = ataque;
        }

        public string GetNombre() => nombre;
        public int GetVida() => vida;
        public int GetAtaque() => ataque;

        public void Atacar(Personaje objetivo)
        {
            int danio = ataque + (equipo?.GetModificadorAtaque() ?? 0);
            objetivo.RecibirDanio(danio);
        }

        public void RecibirDanio(int danio)
        {
            vida -= danio;
            if (vida < 0) vida = 0;
        }

        public void Equipar(Equipo equipo)
        {
            this.equipo = equipo;
        }
    }

    class Equipo
    {
        private int modificadorAtaque;
        private int modificadorArmadura;

        public Equipo(int modificadorAtaque, int modificadorArmadura)
        {
            this.modificadorAtaque = modificadorAtaque;
            this.modificadorArmadura = modificadorArmadura;
        }

        public int GetModificadorAtaque() => modificadorAtaque;
        public int GetModificadorArmadura() => modificadorArmadura;
    }
}